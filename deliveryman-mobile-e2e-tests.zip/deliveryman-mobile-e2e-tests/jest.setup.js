global.PLATFORM = process.env.PLATFORM || 'android'
global.TARGET = process.env.TARGET || 'hml'
global.CI = process.env.CI || false

global.CONFIG = require('./src/config')

global.sleep = time => {
  return new Promise(resolve => setTimeout(resolve, time * 1000))
}

global.wdioOpts = {
  ...CONFIG.server,
  capabilities: CONFIG.caps
}

global.driver = undefined
