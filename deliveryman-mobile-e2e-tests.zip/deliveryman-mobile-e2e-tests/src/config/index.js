const env = require(`./env/${TARGET}`)

env.appiumConfig = CI
  ? process.env.PLATFORM == 'lambdatest'
    ? {
        logLevel: 'info',
        coloredLogs: true,
        baseUrl: '',
        waitforTimeout: 10000,
        connectionRetryTimeout: 90000,
        connectionRetryCount: 3,
        path: '/wd/hub',
        hostname: 'mobile-hub.lambdatest.com',
        port: 80,
        user: process.env.LT_USERNAME,
        key: process.env.LT_ACCESS_KEY
      }
    : {
        user: process.env.TB_USERNAME,
        key: process.env.TB_ACCESS_KEY
      }
  : {
      path: '/wd/hub',
      host: 'localhost',
      port: 4723,
      logLevel: 'info'
    }

global.data = require(`./data`)

module.exports = {
  caps: require(`./platform/${PLATFORM}`).caps,
  server: env.appiumConfig,
  database: env.database
}
