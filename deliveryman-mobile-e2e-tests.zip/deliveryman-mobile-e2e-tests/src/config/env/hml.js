module.exports = {
  database: {
    server: '34.170.186.35',
    port: 1433,
    user: 'devuser',
    password: '/f&_9U3r{A>tZ+an',
    database: 'prod-mottu',
    pool: {
      max: 10,
      min: 0,
      idleTimeoutMillis: 30000
    },
    options: {
      encrypt: false,
      trustServerCertificate: true
    }
  },
  api: {
    orderCreator: {
      baseUrl: 'https://gatewaymottu.mottu.dev'
    },
    backDelivery: {
      baseUrl: 'https://hm-backendentregas.mottu.dev'
    },
    gpGateway: {
      baseUrl: 'https://gp-gateway.mottu.dev'
    },
    appGateway: {
      baseUrl: 'https://gatewayapp.mottu.dev'
    }
  }
}
