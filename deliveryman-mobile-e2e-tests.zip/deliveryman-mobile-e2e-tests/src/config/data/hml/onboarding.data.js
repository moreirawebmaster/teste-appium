module.exports = {
  address: {
    addressWithinArea: {
      addressComplete: 'Rua Cincinato Braga, 100',
      zipCode: '01333-011',
      street: 'Cincinato Braga',
      number: '100',
      city: 'São Paulo',
      state: 'SP'
    },
    addressOutsideArea: {
      addressComplete: 'Av. Antônio da Rocha Viana, 1131 - Bosque, Rio Branco',
      zipCode: '69900-496',
      number: '100'
    },
    addressMexico: {
      addressComplete: 'Calle Pablo Garcia 100',
      zipCode: '09100',
      number: '100',
      street: 'Calle Pablo Garcia',
      city: 'Cidade do México',
      state: 'EM',
      district: 'Juan Escutia'
    }
  },
  cnh: {
    withinCnh: {
      messageMandatory: 'Obrigatório'
    },
    withoutCnh: {
      messageWithoutLicense: 'Não tenho CNH'
    },
    licenseMx: {
      number: '123TESTE456',
      expedition: '10/06/2020',
      issuance: '10/06/2020',
      expirationDate: '10/06/2030',
      nacionality: 'Mexicano',
      rfc: 'Teste123QA415'
    }
  },
  payment: {
    informations: {
      totalValue: '875,00',
      codePixCopySuccess: 'Código Pix copiado com sucesso',
      nameCreditCard: 'Teste Automation QA',
      creditCardNumber: '5577000055770004',
      validateDate: '0330',
      securityCode: '737',
      messagePaymentSuccess: 'Pagamento concluído',
      indicationCode: '117819',
      messageDiscount: 'Desconto do Cupom 117819',
      totalValueWithDiscount: '775,00'
    },
    informationsMx: {
      totalValue: '$2,595',
      codePixCopySuccess: 'Código Pix copiado com sucesso',
      nameCreditCard: 'Teste Automation QA',
      creditCardNumber: '5577000055770004',
      validateDate: '0330',
      securityCode: '737',
      messagePaymentSuccess: 'Pagamento concluído',
      indicationCode: '117819',
      messageDiscount: 'Desconto do Cupom 117819',
      totalValueWithDiscount: '761,00',
      datePayment: '01/02/2023'
    }
  }
}
