const path = require('path')

const caps = {
  platformName: 'Ios',
  'appium:automationName': 'Flutter',
  'appium:autoGrantPermissions': true,
  'appium:orientation': 'PORTRAIT',
  'appium:app': path.resolve(__dirname, '..', '..', '..', 'app', 'app.ipa'),
  'appium:newCommandTimeout': 240
}

module.exports = { caps }
