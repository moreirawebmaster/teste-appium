const caps = {
  platformName: 'Android',
  deviceName: process.env.TB_DEVICE_NAME,
  version: process.env.TB_VERSION,
  app: process.env.TB_APP,
  automationName: 'flutter',
  retryBackoffTime: 500,
  hostname: 'hub.testingbot.com'
}

module.exports = { caps }
