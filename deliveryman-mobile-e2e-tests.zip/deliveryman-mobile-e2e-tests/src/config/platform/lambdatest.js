const caps = {
  platformName: 'android',
  deviceName: 'Huawei P30 Pro',
  platformVersion: '10',
  app: process.env.LT_APP,
  devicelog: true,
  visual: true,
  video: true,
  build: 'TESTE JOHN',
  name: 'NOVO TESTE FLUTTER',
  deviceOrientation: 'portrait',
  autoGrantPermissions: true,
  isRealMobile: true,
  automationName: 'Flutter'
}

module.exports = { caps }
