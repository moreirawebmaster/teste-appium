const Screen = require('./_screen')
const Utils = require('../../utils/helpers/utils')
const { installmentManualPaymentBr } = require('../../utils/api/index')

class PaymentNewUserScreen extends Screen {
  constructor() {
    super('paymentNewUser')

    //tela de escolha de planos e pagamento
    this.selectStore = this.flutterElement('stepPlans_dropdown_store')
    this.selectPrimaryOption = this.flutterElement('global_dropdown_modalItem0')
    this.selectThirdOption = this.flutterElement('global_dropdown_modalItem2')
    this.popupBtnConfirm = this.flutterElement(
      'global_button_confirmSelectedItemModal'
    )
    this.selectPlan = this.flutterElement('stepPlans_select_plan')
    this.choosePlan = this.flutterElement('stepPlans_button_next')

    this.selectGuarantee = this.flutterElement(
      'stepPaymentPlanChoosePage_dropdown_parcels'
    )
    this.amountPay = this.flutterElement(
      'stepPaymentPlanChoose_AmountTotalComponent'
    )
    this.paymentBtnNext = this.flutterElement(
      'stepPaymentPlanChoosePage_button_nextStep'
    )

    //tela de pagamento
    //pagamento pix
    this.btnPaymentPix = this.flutterElement('global_button_paymentType16')
    this.valueTotalPay = this.flutterElement('paymentPageAmountTotalComponent')
    this.btnCopyPixCode = this.flutterElement('paymentType_button_copyPixCode')
    this.messageCopyPixCode = this.flutterElement('successMessage')
    this.btnComeBack = this.flutterElement('backButton')

    //pagamento boleto
    this.paymentBankSlip = this.flutterElement('global_button_paymentType17')

    //pagamento paybylink
    this.selectPaymentPayByLink = this.flutterElement(
      'global_button_paymentType22'
    )
    this.selectPaymentPayByLinkMx = this.flutterElement(
      'global_button_paymentType21'
    )
    this.btnPay = this.flutterElement('payByLink')

    //pagamento cartão de crédito
    this.selectPaymentCreditCard = this.flutterElement(
      'global_button_paymentType2'
    )
    this.selectPaymentCreditCardStripe = this.flutterElement(
      'global_button_paymentType15'
    )
    this.selectPaymentCreditCardStripeBr = this.flutterElement(
      'global_button_paymentType18'
    )
    this.inputName = this.flutterElement('paymentType_input_cardName') //campo nome
    this.inputCreditCardNumber = this.flutterElement(
      'paymentType_input_cardNumber'
    )
    this.inputValidateDate = this.flutterElement(
      'paymentType_input_cardExpirationDate'
    )
    this.inputCvv = this.flutterElement('paymentType_input_cardCVV')
    this.btnNext = this.flutterElement('paymentType_button_payCardMethod')
    this.messagePaymentSuccess = this.flutterElement(
      'chooseCreditCard_text_success'
    )
    this.btnCreditCardNext = this.flutterElement(
      'paymentType_button_payCardMethod'
    )

    //código de indicação
    this.inputIndicationCode = this.flutterElement(
      'stepPaymentPlanChoosePage_input_referralCode'
    )
    this.btnApplyCoupon = this.flutterElement(
      'stepPaymentPlanChoosePage_button_applyCupom'
    )
    this.messageDiscountApplied = this.flutterElement(
      'stepPaymentPlanChoosePage_text_description2'
    )
    this.messagePaymentSuccess = this.flutterElement(
      'chooseCreditCard_text_success'
    )
    this.btnConfirm = this.flutterElement('global_button_popUpConfirm')
  }

  async choosePlans({ totalValue }) {
    await this.selectStore.click()
    await this.selectPrimaryOption.click()
    await this.popupBtnConfirm.click()
    await this.selectPlan.scrollIntoView()
    await sleep(1)
    await this.choosePlan.click()
    await sleep(2)
    //await this.selectGuarantee.click()
    //await this.selectPrimaryOption.click()
    //await this.popupBtnConfirm.click()
    expect(await this.amountPay.text()).toContain(totalValue)
  }

  async installmentPayment({
    nameCreditCard,
    creditCardNumber,
    validateDate,
    securityCode
  }) {
    await this.selectPaymentCreditCard.scrollIntoView()
    await this.selectPaymentCreditCard.click()
    await sleep(2)
    await this.inputName.type(nameCreditCard)
    await this.inputCreditCardNumber.type(creditCardNumber)
    await this.inputValidateDate.type(validateDate)
    await this.inputCvv.type(securityCode)
    await sleep(1)
    await this.btnCreditCardNext.click()
    await sleep(5)
    await this.btnConfirm.click()
  }

  async paymentPix({ totalValue, codePixCopySuccess }) {
    await this.paymentBtnNext.scrollIntoView()
    await sleep(1)
    await this.paymentBtnNext.click()
    await this.btnPaymentPix.scrollIntoView()
    await this.btnPaymentPix.click()
    await sleep(5)
    expect(await this.valueTotalPay.text()).toContain(totalValue)
    await this.btnCopyPixCode.scrollIntoView()
    await sleep(1)
    await this.btnCopyPixCode.click()
    expect(await this.messageCopyPixCode.text()).toContain(codePixCopySuccess)
    await sleep(2)
    await this.btnComeBack.click()
    await sleep(2)
  }

  async paymentPayByLink() {
    await this.selectPaymentPayByLink.scrollIntoView()
    await this.selectPaymentPayByLink.click()
    await sleep(2)
    await this.btnPay.click()
    await driver.switchContext('NATIVE_APP')
    await sleep(1)
    await Utils.clickAndContinue()
    await Utils.btnNotThanks()
    await sleep(5)
    await Utils.returnApp()
    await sleep(1)
    await Utils.btnAppMottu()
    await sleep(3)
    await Utils.btnJustOnce()
    await sleep(1)
    await driver.switchContext('FLUTTER')
    await this.btnComeBack.click()
    await sleep(2)
  }

  async indicationCode({
    indicationCode,
    totalValueWithDiscount,
    messageDiscount
  }) {
    await this.inputIndicationCode.type(indicationCode)
    await sleep(2)
    await this.btnApplyCoupon.scrollIntoView()
    await sleep(1)
    await this.btnApplyCoupon.click()
    await sleep(3)
    expect(await this.messageDiscountApplied.text()).toContain(messageDiscount)
    expect(await this.amountPay.text()).toContain(totalValueWithDiscount)
    await this.paymentBtnNext.scrollIntoView()
    await sleep(1)
    await this.paymentBtnNext.click()
    await sleep(3)
  }

  async paymentPixReferral({ totalValueWithDiscount }) {
    await this.btnPaymentPix.scrollIntoView()
    await this.btnPaymentPix.click()
    await sleep(5)
    expect(await this.valueTotalPay.text()).toContain(totalValueWithDiscount)
    await this.btnComeBack.click()
    await sleep(2)
  }

  async paymentCreditCard({ totalValue }) {
    await this.selectPaymentCreditCard.scrollIntoView()
    await this.selectPaymentCreditCard.click()
    await sleep(2)
    expect(await this.valueTotalPay.text()).toContain(totalValue)
    await this.btnComeBack.click()
    await sleep(2)
  }

  async paymentCreditCardStripeMx({ totalValue }) {
    await this.paymentBtnNext.scrollIntoView()
    await sleep(1)
    await this.paymentBtnNext.click()
    await sleep(2)
    await this.selectPaymentCreditCardStripe.scrollIntoView()
    await this.selectPaymentCreditCardStripe.click()
    await sleep(2)
    expect(await this.valueTotalPay.text()).toContain(totalValue)
    await driver.switchContext('NATIVE_APP')
    await Utils.creditCardStripe()
    await driver.switchContext('FLUTTER')
    await this.btnCreditCardNext.click()
    await sleep(5)
    await this.btnConfirm.click()
  }

  async paymentCreditCardStripe({ totalValue }) {
    await this.selectPaymentCreditCardStripeBr.scrollIntoView()
    await this.selectPaymentCreditCardStripeBr.click()
    await sleep(2)
    expect(await this.valueTotalPay.text()).toContain(totalValue)
    await driver.switchContext('NATIVE_APP')
    await Utils.creditCardStripe()
    await driver.switchContext('FLUTTER')
    await this.btnCreditCardNext.click()
    await sleep(5)
    await this.btnConfirm.click()
  }

  async validateValueCreditCardStripe({ totalValueWithDiscount }) {
    await this.selectPaymentCreditCardStripeBr.scrollIntoView()
    await this.selectPaymentCreditCardStripeBr.click()
    await sleep(2)
    expect(await this.valueTotalPay.text()).toContain(totalValueWithDiscount)
    await sleep(2)
    await installmentManualPaymentBr()
  }

  async paymentPayByLinkReferral({ totalValueWithDiscount }) {
    await this.selectPaymentPayByLink.scrollIntoView()
    await this.selectPaymentPayByLink.click()
    await sleep(2)
    expect(await this.valueTotalPay.text()).toContain(totalValueWithDiscount)
    await this.btnComeBack.click()
    await sleep(2)
  }

  async paymentPaybylinkMx({ totalValue }) {
    await this.selectPlan.scrollIntoView()
    await sleep(1)
    await this.choosePlan.click()
    await sleep(2)
    await this.paymentBtnNext.scrollIntoView()
    await sleep(1)
    await this.paymentBtnNext.click()
    await sleep(2)
    await this.selectPaymentPayByLinkMx.scrollIntoView()
    await this.selectPaymentPayByLinkMx.click()
    await sleep(2)
    expect(await this.valueTotalPay.text()).toContain(totalValue)
    //await this.btnPay.click()
    await sleep(2)
  }
}

module.exports = new PaymentNewUserScreen()
