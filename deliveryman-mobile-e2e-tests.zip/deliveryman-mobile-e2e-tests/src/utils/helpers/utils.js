class Utils {
  /**
   * Get the time difference in seconds
   */
  timeDifference(string, start, end) {
    const elapsed = (end - start) / 1000
    console.log(`${string} It took ${elapsed} seconds.`)
  }

  /**
   * Create a cross platform solution for opening a deep link
   */
  async openDeepLinkUrl(url) {
    const prefix = 'wdio://'

    if (driver.isAndroid) {
      // Life is so much easier
      return driver.execute('mobile:deepLink', {
        url: `${prefix}${url}`,
        package: 'com.wdiodemoapp'
      })
    }

    // We can use `driver.url` on iOS simulators, but not on iOS real devices. The reason is that iOS real devices
    // open Siri when you call `driver.url('')` to use a deep link. This means that real devices need to have a different implementation
    // then iOS sims
    // iOS sims and real devices can be distinguished by their UDID. Based on these sources there is a diff in the UDIDS
    // - https://blog.diawi.com/2018/10/15/2018-apple-devices-and-their-new-udid-format/
    // - https://www.theiphonewiki.com/wiki/UDID
    // iOS sims have more than 1 `-` in the UDID and the UDID is being
    const simulatorRegex = new RegExp('(.*-.*){2,}')

    // Check if we are a simulator
    if (
      'udid' in driver.capabilities &&
      simulatorRegex.test(driver.capabilities.udid)
    ) {
      await driver.url(`${prefix}${url}`)
    } else {
      // Else we are a real device and we need to take some extra steps
      // Launch Safari to open the deep link
      await driver.execute('mobile: launchApp', {
        bundleId: 'com.apple.mobilesafari'
      })

      // Add the deep link url in Safari in the `URL`-field
      // This can be 2 different elements, or the button, or the text field
      // Use the predicate string because  the accessibility label will return 2 different types
      // of elements making it flaky to use. With predicate string we can be more precise
      const addressBarSelector = 'label == "Address" OR name == "URL"'
      const urlFieldSelector =
        'type == "XCUIElementTypeTextField" && name CONTAINS "URL"'
      const addressBar = $(`-ios predicate string:${addressBarSelector}`)
      const urlField = $(`-ios predicate string:${urlFieldSelector}`)

      // Wait for the url button to appear and click on it so the text field will appear
      // iOS 13 now has the keyboard open by default because the URL field has focus when opening the Safari browser
      if (!(await driver.isKeyboardShown())) {
        await addressBar.waitForDisplayed()
        await addressBar.click()
      }

      // Submit the url and add a break
      await urlField.setValue(`${prefix}${url}\uE007`)
    }

    /**
     * PRO TIP:
     * if you started the iOS device with `autoAcceptAlerts:true` in the capabilities then Appium will auto accept the alert that should
     * be shown now. You can then comment out the code below
     */
    // Wait for the notification and accept it
    // When using an iOS simulator you will only get the pop-up once, all the other times it won't be shown
    try {
      const openSelector =
        "type == 'XCUIElementTypeButton' && name CONTAINS 'Open'"
      const openButton = $(`-ios predicate string:${openSelector}`)
      // Assumption is made that the alert will be seen within 2 seconds, if not it did not appear
      await openButton.waitForDisplayed({ timeout: 2000 })
      await openButton.click()
    } catch (e) {
      // ignore
    }
  }

  async allowAlert() {
    await (await driver.$('//android.widget.Button[@text="Permitir"]')).click()
  }

  async denyAllert() {
    await (await driver.$('//android.widget.Button[@text="Deny"]')).click()
  }

  async obturadorCamera() {
    await (
      await driver.$('//android.widget.ImageView[@content-desc="Obturador"]')
    ).click()
  }

  async concluidoPicture() {
    await (
      await driver.$('//android.widget.ImageButton[@content-desc="Concluído"]')
    ).click()
  }

  async clickAndContinue() {
    await (
      await driver.$(
        '/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.support.v4.view.ViewPager/android.widget.FrameLayout/android.widget.Button'
      )
    ).click() //clicar aceitar e continuar
  }

  async btnNotThanks() {
    await (
      await driver.$(
        '/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.support.v4.view.ViewPager/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.Button[1]'
      )
    ).click() // clicar em não obrigado
  }

  async returnApp() {
    await (
      await driver.$(
        '/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[1]/android.widget.FrameLayout[2]/android.webkit.WebView/android.view.View/android.view.View[2]/android.view.View[1]/android.view.View[1]'
      )
    ).click() // clicar em voltar
  }

  async btnAppMottu() {
    await (
      await driver.$(
        '/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.ScrollView/android.widget.ListView/android.widget.LinearLayout[2]/android.widget.LinearLayout/android.widget.TextView[1]'
      )
    ).click() // Clicar no app Mottu
  }

  async btnJustOnce() {
    await (
      await driver.$(
        '/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.Button[1]'
      )
    ).click() // clicar em só uma vez}
  }

  async selectOptionTypeLicenseMx() {
    await (await driver.$('//android.view.View[@content-desc="E"]')).click()
  }

  async creditCardStripe() {
    await (
      await driver.$(
        '/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View[3]/android.widget.FrameLayout/android.widget.LinearLayout/androidx.cardview.widget.CardView/android.view.ViewGroup/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout/android.widget.EditText'
      )
    ).setValue('4242424242424242')
    await (
      await driver.$(
        '/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View[3]/android.widget.FrameLayout/android.widget.LinearLayout/androidx.cardview.widget.CardView/android.view.ViewGroup/android.widget.LinearLayout[1]/android.widget.LinearLayout[2]/android.widget.LinearLayout[1]/android.widget.FrameLayout/android.widget.EditText'
      )
    ).setValue('0330')
    await (
      await driver.$(
        '/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View[3]/android.widget.FrameLayout/android.widget.LinearLayout/androidx.cardview.widget.CardView/android.view.ViewGroup/android.widget.LinearLayout[1]/android.widget.LinearLayout[2]/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.EditText'
      )
    ).setValue('737')
  }
}

module.exports = new Utils()
