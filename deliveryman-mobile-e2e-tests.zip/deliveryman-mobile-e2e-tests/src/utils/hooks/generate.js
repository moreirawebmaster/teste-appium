const curp = require('curp')
const { faker } = require('@faker-js/faker')

async function generateCurp() {
  const persona = curp.getPersona()

  persona.nombre = faker.name.findName()
  persona.apellidoPaterno = faker.name.findName()
  persona.apellidoMaterno = faker.name.findName()
  persona.genero = curp.GENERO.MASCULINO
  persona.fechaNacimiento = '10-06-1992'
  persona.estado = curp.ESTADO.TABASCO
  console.log(curp.generar(persona))

  return curp.generar(persona)
}

module.exports = { generateCurp }
