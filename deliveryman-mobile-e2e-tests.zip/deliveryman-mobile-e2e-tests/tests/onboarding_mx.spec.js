const wdio = require('webdriverio')
const RegistrationScreen = require('../src/screens/android/registration')
const LoginScreen = require('../src/screens/android/login')
const PaymentNewUserScreen = require('../src/screens/android/paymentNewUser')
const ScheduleScreen = require('../src/screens/android/shedule')
const { installmentManualPayment } = require('../src/utils/api/index')
const {
  getLoginCodeNewUser,
  getLoginCodePaidUser,
  getUserMxId,
  getUserMxCpf,
  getAprovedUser,
  getCpfPaidUserMx,
  getPaidUserMxId,
  getLoginCodePaidUserMx
} = require('../src/utils/db/index')
const { generateCurp } = require('../src/utils/hooks/generate')

beforeAll(async () => {
  driver = await wdio.remote(wdioOpts)
  await sleep(8) // need to load the app
  await driver.switchContext('FLUTTER')
})

afterAll(async () => {
  await driver.deleteSession()
})

describe('@onboarding_mx Mexico onboarding flow tests', () => {
  afterEach(async () => {
    await driver.reloadSession()
  })

  //Fluxo de cadastro do usuário
  test('@registration_mx ', async () => {
    await RegistrationScreen.changeCountryMx()

    const userCurp = await generateCurp()
    console.log(userCurp)
    await RegistrationScreen.insertCurp(userCurp)

    const newUserMxData = data.auth.login.newUserMx()
    await RegistrationScreen.basicDataMx(newUserMxData)

    const loginCode = await getLoginCodeNewUser(newUserMxData)
    await LoginScreen.confirmCode(loginCode)

    const addressMexicoData = data.onboarding.address.addressMexico
    await RegistrationScreen.AddressMx(addressMexicoData)

    await RegistrationScreen.stepPictureLicenceMx()

    const licenseData = data.onboarding.cnh.licenseMx
    await RegistrationScreen.manualRegistrationLicenseMx(licenseData)
  })

  //Fluxo de pagamento usuário novo
  test('@paymentNewUser_mx', async () => {
    await RegistrationScreen.changeCountryMx()
    const userMxCpf = await getUserMxCpf()
    await LoginScreen.loginCurp(userMxCpf)
    await sleep(5)

    const userMxId = await getUserMxId()
    await getAprovedUser(userMxId)
    const loginCode = await getLoginCodePaidUser(userMxId)
    await LoginScreen.confirmCode(loginCode)

    const paymentMxData = data.onboarding.payment.informationsMx
    await PaymentNewUserScreen.choosePlans(paymentMxData)

    await PaymentNewUserScreen.paymentCreditCardStripeMx(paymentMxData)

    await PaymentNewUserScreen.paymentPaybylinkMx(paymentMxData)
    await sleep(5)

    await installmentManualPayment()
  })

  test('@scheduling_withdrawal', async () => {
    await RegistrationScreen.changeCountryMx()

    const userPaidMx = await getCpfPaidUserMx()
    await LoginScreen.loginCurp(userPaidMx)
    await sleep(5)

    const paidUserMxId = await getPaidUserMxId()
    const loginCode = await getLoginCodePaidUserMx(paidUserMxId)
    await LoginScreen.confirmCode(loginCode)

    await ScheduleScreen.stepTerms()
    await ScheduleScreen.schedule()
  })
})
