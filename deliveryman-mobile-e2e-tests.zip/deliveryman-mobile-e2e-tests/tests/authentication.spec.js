const wdio = require('webdriverio')
const HomeScreen = require('../src/screens/android/home')
const RegistrationScreen = require('../src/screens/android/registration')
const LoginScreen = require('../src/screens/android/login')
const { getLoginCode } = require('../src/utils/db/index')

beforeAll(async () => {
  driver = await wdio.remote(wdioOpts)
  await sleep(30) // need to load the app
  console.debug(await driver.getContexts())
  //await driver.switchContext('flutter')
})

describe('@authentication Authentication Tests', () => {
  test('@login_success Should be able to login', async () => {
    console.log('iniciando teste')
    await RegistrationScreen.changeCountryBr()
    console.log('Change country ok')
    await driver.deleteSession()
    const activeUser = data.auth.login.user
    console.log(activeUser)

    await LoginScreen.login(activeUser.cpf)
    await sleep(4)

    const loginCode = await getLoginCode(activeUser)
    await LoginScreen.confirmCode(loginCode)

    await sleep(4)
    await HomeScreen.grantPermissions()

    await sleep(4)
    await HomeScreen.marketplaceOnline()

    await HomeScreen.validateLogin(activeUser)
  })
})
