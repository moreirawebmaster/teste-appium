const axios = require('axios').default

const config = require('../../config')

const {
  getLoginCode,
  getUserMxId,
  getAprovedUserId,
  getIdInstallment,
  getValueInstallment
} = require('../db')

const api = axios.create({
  timeout: 60000,
  headers: { 'X-Automation-Header': 'automation' }
})

async function authApp() {
  try {
    const user = data.auth.login.user
    const loginCode = await getLoginCode(user)

    const payload = {
      telefone: user.phone,
      codigoConfirmacao: loginCode
    }

    const response = await api.post(
      `https://backend.mottu.dev/api/v2/Usuario/ValidarTelefone`,
      payload
    )

    return { Authorization: `Bearer ${response.data.dataResult.token}` }
  } catch (error) {
    console.error(error)
  }
}

async function authAdmin() {
  try {
    const user = data.auth.login.userAdmin

    const payload = {
      email: user.email,
      senha: user.senha
    }
    console.log(payload)

    const response = await api.post(
      `https://backend.mottu.dev/api/v2/Usuario/AutenticarPorEmail`,
      payload
    )
    console.log(response)

    return { Authorization: `Bearer ${response.data.dataResult.token}` }
  } catch (error) {
    console.error(error)
  }
}

async function installmentManualPayment() {
  try {
    console.log('-> Installment Manual Payment by API')

    const auth = await authAdmin()
    const userId = await getUserMxId()
    const parcelaId = await getIdInstallment(userId)
    const valueInstallment = await getValueInstallment(userId)
    const paymentMxData = data.onboarding.payment.informationsMx

    const payload = {
      pspReference: '0000000',
      poiReference: '0000000000',
      parcelaId: parcelaId,
      valorPagoTotal: valueInstallment,
      desconto: 0,
      pagamentoData: paymentMxData.datePayment,
      pagamentos: [
        {
          formaPagamento: 11,
          valorPago: valueInstallment
        }
      ]
    }

    console.log(payload)

    const response = await api.post(
      `https://backend.mottu.dev/api/v2/Locacao/BaixaManualParcela`,
      payload,
      { headers: { ...auth } }
    )
    console.log(response)

    return response.data
  } catch (error) {
    console.error(error)
  }
}

async function installmentManualPaymentBr() {
  try {
    console.log('-> Installment Manual Payment by API')

    const auth = await authAdmin()
    const userId = await getAprovedUserId()
    const parcelaId = await getIdInstallment(userId)
    const valueInstallment = await getValueInstallment(userId)
    const paymentMxData = data.onboarding.payment.informationsMx

    const payload = {
      pspReference: '0000000',
      poiReference: '0000000000',
      parcelaId: parcelaId,
      valorPagoTotal: valueInstallment,
      desconto: 0,
      pagamentoData: paymentMxData.datePayment,
      pagamentos: [
        {
          formaPagamento: 11,
          valorPago: valueInstallment
        }
      ]
    }

    console.log(payload)

    const response = await api.post(
      `https://backend.mottu.dev/api/v2/Locacao/BaixaManualParcela`,
      payload,
      { headers: { ...auth } }
    )
    console.log(response)

    return response.data
  } catch (error) {
    console.error(error)
  }
}

async function acceptOrder(order) {
  try {
    console.log('-> Accepting order by API')

    const auth = await authApp()

    const payload = {
      pedidoId: order.id,
      entregadorId: data.auth.login.user.id
    }

    console.log(payload)

    const response = await api.post(
      `${config.api.appGateway.baseUrl}/api/App/aceitarpedido`,
      payload,
      { headers: { ...auth } }
    )

    return response.data
  } catch (error) {
    console.error(error)
  }
}

async function createOrder(orderType = 'online') {
  // online | offline | confirm_code
  try {
    console.log('-> creating order by API')

    const payload = data.order[orderType]

    const response = await api.post(
      `${config.api.orderCreator.baseUrl}/api/admin/GestaoPedidos/criarpedido`,
      payload
    )

    return response.data
  } catch (error) {
    console.error(error)
  }
}

module.exports = {
  acceptOrder,
  createOrder,
  installmentManualPayment,
  installmentManualPaymentBr,
  authAdmin
}
