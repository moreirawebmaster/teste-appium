const sql = require('mssql')

const config = require('../../config')

async function runQuery(query) {
  try {
    await sql.connect(config.database)

    const result = await sql.query(query)

    return result
  } catch (err) {
    throw new Error(err)
  }
}

//busca de código de confirmação pelo id do usuário
async function getLoginCode(user) {
  const table = 'usuarioTelefone'

  const result = await runQuery(
    `select codigoConfirmacao from ${table} where usuarioId = ${user.id}`
  )

  return result.recordset.at(0)['codigoConfirmacao']
}

//busca de código de confirmação de usuário novo pelo telefone
async function getLoginCodeNewUser(user) {
  const table = 'usuarioTelefone'

  const result = await runQuery(
    `select codigoConfirmacao from ${table} where numero = '${user.phone}'`
  )

  return result.recordset.at(0)['codigoConfirmacao']
}

//busca de código de confirmação de usuário pago pelo id
async function getLoginCodePaidUser(id) {
  const table = 'usuarioTelefone'

  const result = await runQuery(
    `select codigoConfirmacao from ${table} where usuarioId = ${id}`
  )
  return result.recordset.at(0)['codigoConfirmacao']
}

//busca de código de confirmação de usuário aprovado pelo id
async function getLoginCodeAprovedUser(id) {
  const table = 'usuarioTelefone'

  const result = await runQuery(
    `select codigoConfirmacao from ${table} where usuarioId = ${id}`
  )
  return result.recordset.at(0)['codigoConfirmacao']
}

//busca de código de confirmação de usuário pago
async function getLoginCodePaidUserMx(id) {
  const table = 'usuarioTelefone'

  const result = await runQuery(
    `select codigoConfirmacao from ${table} where usuarioId = ${id}`
  )
  return result.recordset.at(0)['codigoConfirmacao']
}

//busca de cpf de usuário aprovado
async function getAprovedUserCpf() {
  const result = await runQuery(
    `select top 1 cpf from usuario where id = (select top 1 usuarioid from locacao where situacao = 10 order by usuarioid desc) order by id desc`
  )
  console.log(result)
  return result.recordset.at(0)['cpf']
}

//busca de cpf de usuário pago
async function getUserCpf() {
  const result = await runQuery(
    `select top 1 cpf from usuario where id = (select top 1 usuarioid from locacao where situacao = 20 order by usuarioid desc) order by id desc`
  )
  console.log(result)
  return result.recordset.at(0)['cpf']
}

//busca de curp de usuário do méxico
async function getUserMxCpf() {
  const result = await runQuery(
    `select top 1 cpf from usuario where paisId = 2 order by id desc`
  )
  console.log(result)
  return result.recordset.at(0)['cpf']
}

//busca de cpf de usuário pago méxico
async function getCpfPaidUserMx() {
  const result = await runQuery(
    `select top 1 cpf from usuario where id = (select top 1 usuarioid from locacao where situacao = 20 order by usuarioId desc) and paisId = 2 order by id desc`
  )
  console.log(result)
  return result.recordset.at(0)['cpf']
}

//busca de id de usuário pago
async function getUserId() {
  const result = await runQuery(
    `select top 1 id from usuario where id = (select top 1 usuarioid from locacao where situacao = 20 order by usuarioid desc) order by id desc`
  )
  console.log(result)
  return result.recordset.at(0)['id']
}

//busca de id de usuário do méxico
async function getUserMxId() {
  const result = await runQuery(
    `select top 1 id from usuario where paisId = 2 order by id desc`
  )
  console.log(result)
  return result.recordset.at(0)['id']
}

//busca de id de usuário aprovado
async function getAprovedUserId() {
  const result = await runQuery(
    `select top 1 id from usuario where id = (select top 1 usuarioid from locacao where situacao = 10 order by usuarioid desc) order by id desc`
  )
  console.log(result)
  return result.recordset.at(0)['id']
}

//busca de id de usuário pago méxico
async function getPaidUserMxId() {
  const result = await runQuery(
    `select top 1 id from usuario where id = (select top 1 usuarioid from locacao where situacao = 20 order by usuarioId desc) and paisId = 2 order by id desc`
  )
  console.log(result)
  return result.recordset.at(0)['id']
}

//Aprovar usuário
async function getAprovedUser(id) {
  const result = await runQuery(
    `execute MudarSituacaoUsuario @situacao = 10, @usuarioId = ${id}`
  )
  console.log(result)
  return result
}

async function getPhoneAprovedUser(id) {
  const result = await runQuery(
    `select codigoConfirmacao from usuariotelefone where usuarioId = ${id}`
  )
  console.log(result)
  return result.recordset.at(0)['codigoConfirmacao']
}

async function getValueInstallment(id) {
  const result = await runQuery(
    `select top 1 valorPagar from parcelaRequisicaoPagamento where usuarioid = ${id}`
  )
  console.log(result)
  return result.recordset.at(0)['valorPagar']
}

async function getIdInstallment(id) {
  const result = await runQuery(
    `select top 1 id from parcela where locacaoid = (select top 1 id from locacao where usuarioid = ${id}) and numero = 1`
  )
  console.log(result)
  return result.recordset.at(0)['id']
}

module.exports = {
  getLoginCode,
  getLoginCodeNewUser,
  getUserCpf,
  getUserId,
  getLoginCodePaidUser,
  getUserMxId,
  getUserMxCpf,
  getAprovedUser,
  getAprovedUserCpf,
  getAprovedUserId,
  getLoginCodeAprovedUser,
  getPhoneAprovedUser,
  getValueInstallment,
  getIdInstallment,
  getCpfPaidUserMx,
  getPaidUserMxId,
  getLoginCodePaidUserMx
}
