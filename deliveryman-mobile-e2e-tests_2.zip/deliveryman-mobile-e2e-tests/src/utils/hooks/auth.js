const LoginScreen = require('../../screens/android/login')

const { getLoginCode } = require('../db')

async function loginHook(user, cpf) {
  await LoginScreen.login(cpf)

  await sleep(4)
  const loginCode = await getLoginCode(user)
  await LoginScreen.confirmCode(loginCode)
  await sleep(4)
}

module.exports = { loginHook }
