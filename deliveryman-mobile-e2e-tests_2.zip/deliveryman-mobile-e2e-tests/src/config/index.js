const env = require(`./env/${TARGET}`)

env.appiumConfig = {
  logLevel: 'info',
  coloredLogs: true,
  baseUrl: '',
  waitforTimeout: 10000,
  connectionRetryTimeout: 90000,
  connectionRetryCount: 3,
  path: '/wd/hub',
  hostname: 'mobile-hub.lambdatest.com',
  user: 'thiago.silvamottu',
  key: 'vwSCf9zLQGoE2CYXWCATEV8xmOtuB3xN55mTftKv4lZtzzcooP'
}

global.data = require(`./data`)

module.exports = {
  caps: require(`./platform/${PLATFORM}`).caps,
  server: env.appiumConfig,
  database: env.database
}
