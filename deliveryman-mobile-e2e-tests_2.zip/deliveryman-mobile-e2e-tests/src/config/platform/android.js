const path = require('path')

const caps = {
  platformName: 'Android',
  'appium:app': path.resolve(__dirname, '..', '..', '..', 'app', 'app.apk'),
  'appium:automationName': 'Flutter',
  'appium:orientation': 'PORTRAIT',
  'appium:autoGrantPermissions': true,
  'appium:newCommandTimeout': 240
}

module.exports = { caps }
