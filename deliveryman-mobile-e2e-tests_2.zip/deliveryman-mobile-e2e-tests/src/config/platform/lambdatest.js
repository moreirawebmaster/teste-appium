const caps = {
  platformName: 'Android',
  'appium:app': 'lt://APP10160531401677621172462409',
  'appium:deviceName': 'Pixel 6',
  'appium:platformVersion': '12.0',
  'appium:automationName': 'flutter',
  'lt:options': {
    build: 'TESTE NOVAS CONFIGS',
    name: 'NOVO TESTE FLUTTER',
    isRealMobile: true,
    autoGrantPermissions: true
  }
}

module.exports = { caps }
