module.exports = {
  auth: require(`./${TARGET}/auth.data`),
  onboarding: require(`./${TARGET}/onboarding.data`)
  // maintenance: require(`./${TARGET}/maintenance.data`),
  // payment: require(`./${TARGET}/payment.data`),
}
