const { faker } = require('@faker-js/faker')
const fakerbr = require('faker-br')

module.exports = {
  login: {
    user: {
      id: '667245',
      cpf: '07147564588'
    },
    newUser: () => ({
      cpf: fakerbr.br.cpf(),
      name: 'QA Automation DeliveryMan',
      birthDate: '10/06/1992',
      areaCode: '11',
      phone: faker.random.numeric(9, { allowLeadingZeros: false }),
      email: 'teste@teste.com'
    }),
    newUserMx: () => ({
      name: 'QA Automation DeliveryMan Mx',
      birthDate: '10/06/1992',
      areaCode: '632',
      phone: faker.random.numeric(9, { allowLeadingZeros: false }),
      email: 'teste@teste.com'
    }),
    pageUser: {
      id: '385808',
      cpf: '10042760798'
    },
    userAdmin: {
      email: 'qaadmin@mottu.com.br',
      senha: 'b@75wnqx'
    }
  }
}
