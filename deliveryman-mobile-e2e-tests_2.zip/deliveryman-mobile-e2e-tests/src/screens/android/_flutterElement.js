const find = require('appium-flutter-finder')

module.exports = class FlutterElement {
  constructor(locator) {
    this.locator = this.flutterLocator(locator)
  }

  flutterLocator(locator) {
    return find.byValueKey(locator)
  }

  async click() {
    return driver.elementClick(this.locator)
  }

  async type(text) {
    return driver.elementSendKeys(this.locator, text)
  }

  async text() {
    return driver.getElementText(this.locator)
  }

  async scrollIntoView() {
    return driver.execute('flutter:scrollIntoView', this.locator, {
      alignment: 0.8,
      timeout: 10000
    })
  }

  async dragAndDrop() {
    return driver.execute(
      'flutter:scrollUntilVisible',
      {
        dxScroll: 550,
        dyScroll: -100,
        durationMilliseconds: 2000
      },
      this.locator
    )
    // return driver.touchAction([
    //   { action: 'press', x: 550, y: 1330 },
    //   { action: 'moveTo', x: 2, y: 1330 },
    //   this.locator
    // ])
  }

  async tap() {
    return driver.touchAction([{ action: 'tap', x: 100, y: 20 }, this.locator])
  }

  async back() {
    return driver.back()
  }

  async wait() {
    // not working
    return driver.execute('flutter:waitFor', this.locator)
  }
}
