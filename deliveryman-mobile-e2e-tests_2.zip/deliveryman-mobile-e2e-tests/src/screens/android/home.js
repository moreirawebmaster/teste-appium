const Screen = require('./_screen')
const Utils = require('../../utils/helpers/utils')

class HomeScreen extends Screen {
  constructor() {
    super('home')

    this.idUser = this.flutterElement('global_text_userId')

    this.switchMarketplace = this.flutterElement(
      'homeLoggedIn_header_switchStatus_switch'
    )
    this.textMarketplace = this.flutterElement(
      'homeLoggedIn_header_switchStatus_title'
    )
    this.textOnlineListing = this.flutterElement(
      'homeLoggedIn_text_emptyOrders'
    )
    this.textOfflineListing = this.flutterElement(
      'homeLoggedIn_text_turnOnlineToTakeOrders'
    )

    this.lateralMenu = this.flutterElement('homeLoggedIn_header_content')
  }

  async grantPermissions() {
    await driver.switchContext('NATIVE_APP')
    await sleep(3)
    await (await driver.$('#btNext')).click() // * lets go
    await sleep(3)
    await (await driver.$('#btNext')).click() // * battery optimization
    await sleep(3)
    await Utils.allowAlert()
    await sleep(3)
    await (await driver.$('#btNext')).click() // * lets go delivery
    await driver.switchContext('FLUTTER')
  }

  async validateLogin({ id }) {
    await sleep(5)
    expect(await this.idUser.text()).toContain(id)
    await this.lateralMenu.click()
    await sleep(3)
    expect(await this.idUser.text()).toContain(id)
  }

  async marketplaceOnline() {
    expect(await this.textMarketplace.text()).toContain('Offline')
    await this.switchMarketplace.click()
    await sleep(3)
    expect(await this.textOnlineListing.text()).toContain(
      'Sem pedidos disponíveis no momento'
    )

    expect(await this.textMarketplace.text()).toContain('Online')
    await this.switchMarketplace.click()
    await sleep(3)
    expect(await this.textOfflineListing.text()).toContain(
      'Fique online para receber pedidos'
    )
    await sleep(2)
    await this.switchMarketplace.click()
  }
}

module.exports = new HomeScreen()
