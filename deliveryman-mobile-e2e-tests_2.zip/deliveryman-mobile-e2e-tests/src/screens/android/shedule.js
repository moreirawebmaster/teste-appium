const Screen = require('./_screen')
const find = require('appium-flutter-finder')

class ScheduleScreen extends Screen {
  constructor() {
    super('scheduling')

    this.btnNextTerms = this.flutterElement('step_terms_button_next')
    this.textTermsMottu = this.flutterElement('step_terms_text_title0')
    this.textTermsPayments = this.flutterElement('step_terms_text_title1')
    this.textTermsMaintenance = this.flutterElement('step_terms_text_title2')
    this.textTermsTraffic = this.flutterElement('step_terms_text_title3')
    this.textTermsLending = this.flutterElement('step_terms_text_title4')
    this.textTermsSupportUse = this.flutterElement('step_terms_text_title5')
    this.selectDate = this.flutterElement('stepScheduleWithdraw_dropdown_date')
    this.popupBtnConfirm = this.flutterElement(
      'global_button_confirmSelectedItemModal'
    )
    this.dropDownTime = this.flutterElement(
      'stepScheduleWithdraw_dropdown_hour'
    )
    this.selectOption0 = this.flutterElement('global_dropdown_modalItem0')
    this.btnSchedule = this.flutterElement('stepScheduleWithdraw_button_next')
    this.scheduledDate = this.flutterElement('stepWaitingWhitdrawal_text_date')
    this.btnSchedulling = this.flutterElement(
      'stepWaitingWhitdrawal_button_reSchedule'
    )
  }

  async stepTerms() {
    //Regras da Mottu
    expect(await this.textTermsMottu.text()).toContain('Regras Mottu')
    await sleep(2)
    await this.btnNextTerms.click()
    await sleep(1)

    //Regra de pagamentos
    expect(await this.textTermsPayments.text()).toContain(
      'Regras de Pagamentos'
    )
    await sleep(2)
    await this.btnNextTerms.click()
    await sleep(1)

    //Regras de manutenção
    expect(await this.textTermsMaintenance.text()).toContain(
      'Regras de Manutenção'
    )
    await sleep(2)
    await this.btnNextTerms.click()
    await sleep(1)

    //Regras de trânsito
    expect(await this.textTermsTraffic.text()).toContain('Regras de Trânsito')
    await sleep(2)
    await this.btnNextTerms.click()
    await sleep(1)

    //Regras de empréstimo
    expect(await this.textTermsLending.text()).toContain('Regras de Empréstimo')
    await sleep(2)
    await this.btnNextTerms.click()
    await sleep(1)

    //Apoio as normas de uso
    expect(await this.textTermsSupportUse.text()).toContain(
      'Apoio as normas de uso'
    )
    await sleep(2)
    await this.btnNextTerms.click()
    await sleep(2)
  }

  async schedule() {
    await this.selectDate.click()
    await sleep(1)

    await driver.elementClick(
      await find.descendant({
        of: find.byValueKey('global_tableCalendar_widget'),
        matching: find.byText(new Date().getDate().toString())
      })
    )

    await sleep(1)
    await this.popupBtnConfirm.click()
    await sleep(2)
    await this.dropDownTime.click()
    await this.selectOption0.click()
    await this.popupBtnConfirm.click()
    await this.btnSchedule.click()
    await sleep(5)
    // expect(await this.scheduledDate.text()).toContain(
    //   new Date().getDate().toString()
    // )
  }

  async rescheduling() {
    await this.btnSchedulling.click()
    await sleep(1)
    await this.selectDate.click()

    await driver.elementClick(
      await find.descendant({
        of: find.byValueKey('global_tableCalendar_widget'),
        matching: find.byText(new Date().getDate().toString())
      })
    )

    await sleep(1)
    await this.popupBtnConfirm.click()
    await sleep(2)
    await this.dropDownTime.click()
    await this.selectOption0.click()
    await this.popupBtnConfirm.click()
    await this.btnSchedule.click()
    await sleep(5)
    expect(await this.scheduledDate.text()).toContain(
      new Date().getDate().toString()
    )
  }
}

module.exports = new ScheduleScreen()
