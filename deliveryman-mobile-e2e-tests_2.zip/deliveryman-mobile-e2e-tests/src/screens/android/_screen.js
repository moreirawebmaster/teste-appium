const FlutterElement = require('./_flutterElement')

module.exports = class Screen {
  constructor(selector) {
    this.selector = new FlutterElement(selector)
  }

  flutterElement(locator) {
    return new FlutterElement(locator)
  }

  async load() {
    // not working
    return this.selector.wait()
  }
}
