const Screen = require('./_screen')
const utils = require('../../utils/helpers/utils')
class RegistrationScreen extends Screen {
  constructor() {
    super('registration')

    //Escolha de país
    //this.btnChangeCountry = this.flutterElement('logIn_button_changeCounty')
    this.selectChangeCountry = this.flutterElement('country_dropdown_select')
    this.selectSecondOptionModal = this.flutterElement(
      'global_dropdown_modalItem1'
    )

    this.selectPrimaryOptionModal = this.flutterElement(
      'global_dropdown_modalItem0'
    )
    this.popupBtnConfirm = this.flutterElement(
      'global_button_confirmSelectedItemModal'
    )
    this.btnConfirmChangeCountry = this.flutterElement(
      'country_button_ConfirmChangeCountry'
    )

    //Home deslogada
    this.inputCpf = this.flutterElement('logIn_input_cpf')
    this.loginBtnNext = this.flutterElement('logIn_button_btNext')

    this.inputCurp = this.flutterElement('logIn_input_curp')

    //tela de dados básicos
    this.inputName = this.flutterElement('stepInitialDataPage_input_name')
    this.inputBirthDate = this.flutterElement('stepInitialDataPage_input_birth')
    this.inputAreaCode = this.flutterElement(
      'stepInitialDataPage_input_areaCode'
    )
    this.inputPhoneNumber = this.flutterElement(
      'stepInitialDataPage_input_phoneNumber'
    )
    this.checkboxTerms = this.flutterElement('stepInitialDataPage_check_terms')
    this.checkboxContract = this.flutterElement(
      'stepInitialDataPage_check_contract'
    )
    this.basicDataBtnNext = this.flutterElement(
      'stepInitialDataPage_button_next'
    )

    //tela de endereço
    this.inputAddressComplete = this.flutterElement(
      'stepAddressPage_input_address'
    )
    this.dontFindAddress = this.flutterElement(
      'stepAddressPage_button_dontFindAddress'
    )
    this.inputZipCode = this.flutterElement(
      'stepAddressManual_input_zipCode_br'
    )
    this.inputZipCodeMx = this.flutterElement(
      'stepAddressManual_input_zipCode_mx'
    )
    this.inputDetailsZipCode = this.flutterElement(
      'stepAddressManualDetails_input_zipCode'
    )
    this.manualAddressBtnNext = this.flutterElement(
      'stepAddressManual_button_next'
    )
    this.inputStreet = this.flutterElement(
      'stepAddressManualDetails_input_street'
    )
    this.inputNumber = this.flutterElement(
      'stepAddressManualDetails_input_number'
    )
    this.inputCity = this.flutterElement('stepAddressManualDetails_input_city')
    this.inputState = this.flutterElement(
      'stepAddressManualDetails_input_state'
    )
    this.inputDistrict = this.flutterElement(
      'stepAddressManualDetails_input_district'
    )
    this.manualDetailsAddressBtnNext = this.flutterElement(
      'stepAddressManualDetails_button_next'
    )

    this.btnNextAddress = this.flutterElement('stepAddressPage_button_next')
    this.inputEmail = this.flutterElement('stepAddressOutOfRange_input_email')
    this.btnSendEmail = this.flutterElement('stepAddressOutOfRange_button_send')
    this.optionAddressComplete = this.flutterElement(
      'global_button_optionInput0'
    )

    //tela de CNH
    this.btnPicture = this.flutterElement(
      'stepDriverLicense_button_sendPicture'
    )
    this.btnConfirmInformation = this.flutterElement(
      'stepDriverLicenseConfirmation_button_confirmInformation'
    )
    this.messageMandatoryCnh = this.flutterElement(
      'stepDriverLicenseConfirmation_text_successMessage'
    )
    this.popupBtnClose = this.flutterElement('global_button_popUpConfirm')
    this.checkCnhOk = this.flutterElement(
      'stepDriverLicenseConfirmation_check_chnOk'
    )
    this.checkCnhValid = this.flutterElement(
      'stepDriverLicenseConfirmation_check_chnValid'
    )
    this.checkCnhDateValid = this.flutterElement(
      'stepDriverLicenseConfirmation_check_chnDateValid'
    )
    this.btnDontHaveCnh = this.flutterElement(
      'stepDriverLicenseConfirmation_button_dontHaveLicense'
    )
    this.messageDontHaveCnh = this.flutterElement(
      'stepUserStatusPage_text_plansTitle'
    )
    this.messageDontHaveCnh = this.flutterElement(
      'stepUserStatusPage_text_statusTitle'
    )
    this.btnPopupCamera = this.flutterElement('global_button_popUpCancel')

    this.btnCameraNext = this.flutterElement(
      'helpDriverLicense_button_continue'
    )
    this.btnCamera = this.flutterElement('camera_button_id')
    this.btnCameraPictureNext = this.flutterElement(
      'helpTakePictureDriverLicense_button_continue'
    )
    this.btnPictureConfirm = this.flutterElement('global_button_yes')

    this.selectTypeLicense = this.flutterElement(
      'stepDriverLicensePageManualMexico_dropdown_driverLicenseType'
    )
    this.selectOptionLicense = this.flutterElement(
      'stepDriverLicensePageManualMexico_dropdown_driverLicenseType_item_9'
    )
    this.inputLicenseNumber = this.flutterElement(
      'stepDriverLicensePageManualMexico_input_licenseNumber'
    )
    this.inputExpedition = this.flutterElement(
      'stepDriverLicensePageManualMexico_input_expedicion'
    )
    this.inputIssuance = this.flutterElement(
      'stepDriverLicensePageManualMexico_input_issuance'
    )
    this.inputExpirationDate = this.flutterElement(
      'stepDriverLicensePageManualMexico_input_expirationDate'
    )
    this.inputNacionality = this.flutterElement(
      'stepDriverLicensePageManualMexico_input_nacionality'
    )
    this.inputRfc = this.flutterElement(
      'stepDriverLicensePageManualMexico_input_rfc'
    )
    this.btnNextManualLicenseMx = this.flutterElement(
      'stepDriverLicensePageManualMexico_button_next'
    )
    this.btnConfirm = this.flutterElement('global_button_popUpConfirm')

    this.validateRegistrationComplete = this.flutterElement(
      'stepDriverLicensePageManualMexico_success'
    )
    this.statusRegistrationUser = this.flutterElement(
      'stepUserStatusPage_text_statusTitle'
    )
  }

  async changeCountryMx() {
    //await this.btnChangeCountry.click()
    await sleep(2)
    await this.selectChangeCountry.click()
    await this.selectSecondOptionModal.click()
    await this.popupBtnConfirm.click()
    await this.btnConfirmChangeCountry.click()
    await sleep(2)
  }

  async changeCountryBr() {
    //await this.btnChangeCountry.click()
    await sleep(2)
    await this.selectChangeCountry.click()
    await this.selectPrimaryOptionModal.click()
    await this.popupBtnConfirm.click()
    await this.btnConfirmChangeCountry.click()
    await sleep(4)
  }

  async insertCurp(userCurp) {
    await this.inputCurp.type(userCurp)
    await sleep(1)
    await this.loginBtnNext.click()
    await sleep(2)
  }

  async basicDataMx({ name, birthDate, areaCode, phone }) {
    await this.inputName.type(name)
    await this.inputBirthDate.type(birthDate)
    await this.inputAreaCode.type(areaCode)
    await this.inputPhoneNumber.type(phone)
    await this.checkboxTerms.click()
    await this.checkboxContract.click()
    await sleep(1)
    await this.basicDataBtnNext.click()
  }

  async basicData({ cpf, name, birthDate, areaCode, phone }) {
    await this.inputCpf.type(cpf)
    await sleep(1)
    await this.loginBtnNext.click()
    await sleep(2)

    await this.inputName.type(name)
    await this.inputBirthDate.type(birthDate)
    await this.inputAreaCode.type(areaCode)
    await this.inputPhoneNumber.type(phone)
    await this.checkboxTerms.click()
    await this.checkboxContract.click()
    await sleep(1)
    await this.basicDataBtnNext.click()
  }

  async addressBr({ addressComplete }) {
    await sleep(5)
    await this.inputAddressComplete.type(addressComplete)
    await sleep(3)
    await this.optionAddressComplete.click()
    await sleep(5)
    await this.btnNextAddress.click()
  }

  async manualAddress({ zipCode, addressComplete, number }) {
    await sleep(5)
    await this.inputAddressComplete.type(addressComplete)
    await sleep(3)
    await this.dontFindAddress.click()
    await sleep(5)
    await this.inputZipCode.click()
    await this.inputZipCode.type(zipCode)
    await sleep(1)
    await this.manualAddressBtnNext.click()
    await sleep(2)
    await this.inputNumber.type(number)
    await this.inputDetailsZipCode.click()
    await sleep(1)
    await this.manualDetailsAddressBtnNext.scrollIntoView()
    await sleep(1)
    await this.manualDetailsAddressBtnNext.click()
  }

  async AddressMx({ addressComplete }) {
    await sleep(5)
    await this.inputAddressComplete.type(addressComplete)
    await sleep(3)
    await this.optionAddressComplete.click()
    await sleep(5)
    await this.btnNextAddress.click()
  }

  async validateAddressOutsideArea({ email }) {
    await this.inputEmail.type(email)
    await this.btnSendEmail.click()
    await sleep(2)
    await this.popupBtnClose.click()
  }

  async registrationCnh(messageMandatory) {
    await sleep(2)
    await this.btnConfirmInformation.click()
    await sleep(2)
    expect(await this.messageMandatoryCnh.text()).toContain(messageMandatory)
    await this.popupBtnClose.click()
    await this.checkCnhOk.click()
    await this.checkCnhValid.click()
    await this.checkCnhDateValid.click()
    await sleep(1)
    await this.btnConfirmInformation.click()
  }

  async registrationWithoutLincense(DontHaveCnhMessage) {
    await this.btnDontHaveCnh.click()
    await sleep(3)
    expect(await this.messageDontHaveCnh.text()).toContain(DontHaveCnhMessage)
  }

  async stepPictureLicenceMx() {
    await sleep(5)
    await this.btnPicture.click()
    await sleep(2)
    await this.btnPopupCamera.click()
    await this.btnCameraNext.click()
    await this.btnCamera.click()
    await this.btnPictureConfirm.click()
    await sleep(2)
  }

  async manualRegistrationLicenseMx({
    number,
    expedition,
    issuance,
    expirationDate,
    nacionality,
    rfc
  }) {
    await this.selectTypeLicense.click()
    await sleep(2)
    await driver.switchContext('NATIVE_APP')
    await utils.selectOptionTypeLicenseMx()
    await driver.switchContext('FLUTTER')
    await sleep(1)

    await this.inputLicenseNumber.type(number)
    await this.inputExpedition.type(expedition)
    await this.inputIssuance.type(issuance)
    await this.inputExpirationDate.type(expirationDate)
    await this.btnNextManualLicenseMx.scrollIntoView()
    await this.inputNacionality.type(nacionality)
    await this.inputRfc.type(rfc)
    await this.btnNextManualLicenseMx.click()
    await sleep(3)
    // expect(await this.validateRegistrationComplete.text()).toContain(
    //   'CADASTRO COMPLETO'
    // )
    await this.btnConfirm.click()
    await sleep(3)
    //expect(await this.statusRegistrationUser.text()).toContain('Em análise')
  }
}

module.exports = new RegistrationScreen()
