const Screen = require('./_screen')

class LoginScreen extends Screen {
  constructor() {
    super('login')

    this.inputCpf = this.flutterElement('logIn_input_cpf')
    this.inputCurp = this.flutterElement('logIn_input_curp')
    this.loginBtnNext = this.flutterElement('logIn_button_btNext')

    this.inputSmsCode1 = this.flutterElement('otp_input_code01')
    this.inputSmsCode2 = this.flutterElement('otp_input_code02')
    this.inputSmsCode3 = this.flutterElement('otp_input_code03')
    this.inputSmsCode4 = this.flutterElement('otp_input_code04')
    this.otpBtnNext = this.flutterElement('otp_button_nextStep')
  }

  async login(cpf) {
    await this.inputCpf.type(cpf)
    await sleep(1)
    await this.loginBtnNext.click()
  }

  async loginAprovedUser(AprovedUserCpf) {
    await this.inputCpf.type(AprovedUserCpf)
    await sleep(1)
    await this.loginBtnNext.click()
  }

  async loginCurp(userMxCpf) {
    await this.inputCurp.type(userMxCpf)
    await sleep(1)
    await this.loginBtnNext.click()
  }

  async confirmCode(loginCode) {
    await this.inputSmsCode1.type(loginCode[0])
    await this.inputSmsCode2.type(loginCode[1])
    await this.inputSmsCode3.type(loginCode[2])
    await this.inputSmsCode4.type(loginCode[3])

    await sleep(3)
    await this.otpBtnNext.click()
  }

  async invalidLogin({ cpf }) {
    await this.inputCpf.type(cpf)
  }

  async validateMessageError({ message }) {
    expect(await this.inputCpf.text()).toEqual(message)
  }
}

module.exports = new LoginScreen()
