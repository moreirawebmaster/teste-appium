global.PLATFORM = 'lambdatest'
global.TARGET = 'hml'
global.CI = true

global.CONFIG = require('./src/config')

global.sleep = time => {
  return new Promise(resolve => setTimeout(resolve, time * 1000))
}

global.wdioOpts = {
  ...CONFIG.server,
  capabilities: CONFIG.caps
}

global.driver = undefined
