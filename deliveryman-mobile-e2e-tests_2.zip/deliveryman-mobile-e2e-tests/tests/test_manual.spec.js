const wdio = require('webdriverio')
const assert = require('assert')
const { byValueKey } = require('appium-flutter-finder')

const caps = {
  platformName: 'Android',
  deviceName: 'Pixel 6a',
  version: '13.0',
  realDevice: false,
  app: 'https://github.com/testingbot/flutter-demo-app/releases/download/v1.0.0/demo.apk' // or tb://[yourapp]'
}

const opts = {
  capabilities: {
    ...caps,
    automationName: 'Flutter',
    retryBackoffTime: 500,
    hostname: 'hub.testingbot.com'
  },
  user: 'e639f6457745de6f73663a5a66477809',
  key: 'c8601e49c4269533b129cbaed6b0e5ae'
}

test('Teste manual', async () => {
  const counterTextFinder = byValueKey('counter')
  const buttonFinder = byValueKey('incrementButton')

  const driver = await wdio.remote(opts)

  assert.strictEqual(await driver.getElementText(counterTextFinder), '0')

  await driver.elementClick(buttonFinder)
  await driver.touchAction({
    action: 'tap',
    element: { elementId: buttonFinder }
  })

  assert.strictEqual(await driver.getElementText(counterTextFinder), '2')

  driver.deleteSession()
})
