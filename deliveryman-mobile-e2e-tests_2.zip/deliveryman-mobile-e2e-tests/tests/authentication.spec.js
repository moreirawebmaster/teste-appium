const wdio = require('webdriverio')
const HomeScreen = require('../src/screens/android/home')
const RegistrationScreen = require('../src/screens/android/registration')
const LoginScreen = require('../src/screens/android/login')
const { getLoginCode } = require('../src/utils/db/index')

beforeAll(async () => {
  driver = await wdio.remote(wdioOpts)
  await sleep(8) // need to load the app
  await driver.switchContext('FLUTTER')
})

afterAll(async () => {
  await driver.deleteSession()
})

describe('@authentication Authentication Tests', () => {
  test('@login_success Should be able to login', async () => {
    await RegistrationScreen.changeCountryBr()

    const activeUser = data.auth.login.user
    console.log(activeUser)

    await LoginScreen.login(activeUser.cpf)
    await sleep(4)

    const loginCode = await getLoginCode(activeUser)
    await LoginScreen.confirmCode(loginCode)

    await sleep(4)
    await HomeScreen.grantPermissions()

    await sleep(4)
    await HomeScreen.marketplaceOnline()

    await HomeScreen.validateLogin(activeUser)
  })
})
