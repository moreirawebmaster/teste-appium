const wdio = require('webdriverio')
const RegistrationScreen = require('../src/screens/android/registration')
const PaymentNewUserScreen = require('../src/screens/android/paymentNewUser')
const LoginScreen = require('../src/screens/android/login')
const ScheduleScreen = require('../src/screens/android/shedule')
const {
  getLoginCodeNewUser,
  getAprovedUserCpf,
  getAprovedUserId,
  getLoginCodeAprovedUser,
  getUserCpf,
  getUserId,
  getLoginCodePaidUser
} = require('../src/utils/db/index')

beforeAll(async () => {
  driver = await wdio.remote(wdioOpts)
  await sleep(8) // need to load the app
  await driver.switchContext('FLUTTER')
})

afterAll(async () => {
  await driver.deleteSession()
})

describe('@onboarding_br Brazil onboarding flow tests', () => {
  afterEach(async () => {
    await driver.reloadSession()
  })

  test('@registration_user_address_without_area Should be able to login', async () => {
    await RegistrationScreen.changeCountryBr()

    const newUserData = data.auth.login.newUser()
    await RegistrationScreen.basicData(newUserData)

    const loginCode = await getLoginCodeNewUser(newUserData)
    await LoginScreen.confirmCode(loginCode)

    await sleep(5)
    const addressOutsideArea = data.onboarding.address.addressOutsideArea
    await RegistrationScreen.manualAddress(addressOutsideArea)

    await RegistrationScreen.validateAddressOutsideArea(newUserData)
  })

  test('@registration_user_without_cnh', async () => {
    await RegistrationScreen.changeCountryBr()

    const newUserData = data.auth.login.newUser()
    await RegistrationScreen.basicData(newUserData)

    const loginCode = await getLoginCodeNewUser(newUserData)
    await LoginScreen.confirmCode(loginCode)
    await sleep(5)

    const addressWithinAreaData = data.onboarding.address.addressWithinArea
    await RegistrationScreen.addressBr(addressWithinAreaData)

    const DontHaveCnhMessage =
      data.onboarding.cnh.withoutCnh.messageWithoutLicense
    await RegistrationScreen.registrationWithoutLincense(DontHaveCnhMessage)
  })

  test('@registration_user_complete ', async () => {
    await RegistrationScreen.changeCountryBr()

    const newUserData = data.auth.login.newUser()
    await RegistrationScreen.basicData(newUserData)

    const loginCode = await getLoginCodeNewUser(newUserData)
    await LoginScreen.confirmCode(loginCode)
    await sleep(5)

    const addressWithinAreaData = data.onboarding.address.addressWithinArea
    await RegistrationScreen.addressBr(addressWithinAreaData)

    const messageMandatoryCnh = data.onboarding.cnh.withinCnh.messageMandatory
    await RegistrationScreen.registrationCnh(messageMandatoryCnh)

    await sleep(5)
  })

  test('@payment_new_user_test', async () => {
    await RegistrationScreen.changeCountryBr()

    const AprovedUserCpf = await getAprovedUserCpf()
    console.log(AprovedUserCpf)
    await LoginScreen.loginAprovedUser(AprovedUserCpf)
    await sleep(4)

    const aprovedUserId = await getAprovedUserId()
    const loginCode = await getLoginCodeAprovedUser(aprovedUserId)
    await LoginScreen.confirmCode(loginCode)
    await sleep(5)

    const paymentData = data.onboarding.payment.informations
    await PaymentNewUserScreen.choosePlans(paymentData)

    await PaymentNewUserScreen.paymentPix(paymentData)

    await PaymentNewUserScreen.paymentCreditCardStripe(paymentData)
  })

  test('@payment_new_user_within_referral', async () => {
    await RegistrationScreen.changeCountryBr()

    const AprovedUserCpf = await getAprovedUserCpf()
    console.log(AprovedUserCpf)
    await LoginScreen.loginAprovedUser(AprovedUserCpf)
    await sleep(4)

    const aprovedUserId = await getAprovedUserId()
    const loginCode = await getLoginCodeAprovedUser(aprovedUserId)
    await LoginScreen.confirmCode(loginCode)
    await sleep(5)

    const paymentData = data.onboarding.payment.informations
    await PaymentNewUserScreen.choosePlans(paymentData)

    await PaymentNewUserScreen.indicationCode(paymentData)

    await PaymentNewUserScreen.paymentPixReferral(paymentData)

    await PaymentNewUserScreen.validateValueCreditCardStripe(paymentData)
  })

  test('@schedule_withdrow', async () => {
    await RegistrationScreen.changeCountryBr()

    const userCpf = await getUserCpf()
    await LoginScreen.login(userCpf)
    await sleep(5)

    const userId = await getUserId()
    const loginCode = await getLoginCodePaidUser(userId)
    await LoginScreen.confirmCode(loginCode)

    await ScheduleScreen.stepTerms()
    await ScheduleScreen.schedule()

    //await ScheduleScreen.rescheduling()
  })
})
