# boilerplate-mobile-e2e-tests

Template for mobile e2e tests.

The project uses structures for large-scale maintenance, performance and reuse, such as:

- Screen Objects Model
- Centralized test data with control structure (factory)
- Multi-environment configuration (dynamic test data)
- Multiple devices
- Deep validations (feature validated as a whole)
- Real e2e tests -> simulating user
- Happy and sad flow validation

## Requirements

- [Node.js](https://nodejs.org)
- [Yarn](https://yarnpkg.com)
- [VSCode](https://code.visualstudio.com)
- [Java SDK](https://www.oracle.com/java/technologies/javase/jdk17-archive-downloads.html)
- [Android Studio](https://developer.android.com/studio)

### VSCode Required Extensions

- `VisualStudioExptTeam.vscodeintellicode`
- `EditorConfig.EditorConfig`
- `dbaeumer.vscode-eslint`
- `esbenp.prettier-vscode`

### VSCode Recommended Extensions

- `christian-kohler.path-intellisense`
- `aaron-bond.better-comments`
- `PKief.material-icon-theme`
- `oderwat.indent-rainbow`
- `Gruntfuggly.todo-tree`
- `natqe.reload`

## Setup

### Install appium and flutter driver

Appium:

```bash
npm install -g appium@next
```

Flutter Driver:

```bash
appium driver install flutter
```

### Install dependencies

```sh
yarn install
```

To checkup configuration, run the command:

```sh
yarn appium-doctor
```

### Appium Inspector

Mapping elements and test simulations can be made with appium inspector.

Download and install [appium inspector](https://github.com/appium/appium-inspector/releases).

### Desired Capabilities

Appium uses desired capabilities to setup devices and tests. For more details on appium desired capabilities, [see this docs](https://github.com/appium/appium/blob/master/docs/en/writing-running-appium/caps.md).

### Application to test

Inside the `app` folder, you can drop the apk/ipa you want to use in the tests.

> The default name configured is `app.apk`/`app.ipa`, but you can change this in `src/config/platform` configs.

## Running

### Appium Inspector

#### Run appium server first

Appium Inspector needs appium server running to interact with the device.

```sh
yarn appium
```

#### Use the sample configuration

In `docs/appium-inspector` path have sample configuration files that you can use for appium inspector, only changing the path to de apk.

> You can import this sample files in appium inspector using `File -> Open` option.

### Run tests (2 terminals needed)

Terminal 1:

```sh
yarn appium
```

Terminal 2:

```sh
yarn test
```

## Dependencies

- [appium](https://appium.io)
- [webdriverio (standalone)](https://webdriver.io)
- [faker](https://fakerjs.dev)
- [mssql](https://github.com/tediousjs/node-mssql)
- [eslint](https://eslint.org)
- [prettier](https://prettier.io)

---

- add to path vars

%ANDROID_HOME%\platform-tools
