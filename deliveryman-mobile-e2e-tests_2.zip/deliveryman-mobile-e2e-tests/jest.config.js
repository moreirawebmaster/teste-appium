const jestConfig = {
  moduleDirectories: ['node_modules', __dirname],
  setupFilesAfterEnv: ['<rootDir>/jest.setup.js'],
  testTimeout: 9999 * 1000
}

module.exports = jestConfig
